# TELÕES MORTAL v1.0 — projeto Android

Projeto Android Studio com ícone de launcher padrão e painel em tela cheia, neon verde/preto. É independente e demonstrativo; não se integra ao Free Fire, não implementa cheats e não garante anti-ban.

## Gerar APK
1. Abra esta pasta no Android Studio.
2. Instale o Android SDK 35 se solicitado.
3. Aguarde a sincronização do Gradle.
4. Selecione Build > Build APK(s).
5. O APK de debug ficará normalmente em `app/build/outputs/apk/debug/app-debug.apk`.

Este pacote contém código-fonte, não um APK pré-compilado.
