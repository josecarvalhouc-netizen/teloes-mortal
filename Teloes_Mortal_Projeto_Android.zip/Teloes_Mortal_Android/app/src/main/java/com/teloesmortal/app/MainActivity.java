package com.teloesmortal.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5,9,7));
        getWindow().setNavigationBarColor(Color.rgb(5,9,7));
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(5,9,7));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
}
